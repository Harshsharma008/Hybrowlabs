function letterCount (str) {
    const counts= [];
    const demo = str.toUpperCase().replace( /\s/g, '');
    const countMap = new Map();

    for(const  char of demo){
        countMap.set(char,(countMap.get(char) || 0)+1);
    }
const printed = new Set();
for(const char of demo){
    if(!printed.has(char)){
        console.log(`${char}-${countMap.get(char)}`);
        printed.add(char)
    }
}
}

letterCount("Amolya Sharma");