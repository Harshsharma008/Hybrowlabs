import './App.css';
import React, {useState} from 'react';
import axios from 'axios';
function App() {

  const [records, setRecords] = useState([]);
  
  const addRecord = async()=>{
    const randomId = Math.floor(Math.random()* 83)+1;
    const apiUrl = `https://swapi.dev/api/people/${randomId}/`;
    try {
      const response = await axios.get(apiUrl);
      console.log(response)
      const newRecord = {
        id:new Date().getTime(),
        name: response.data.name,

      };
      setRecords([...records, newRecord ])
      
    } catch (error) {
      console.log(error,"<--error");
      alert('Failed to fetch the data');
    }
  }
  console.log(records,"<<--records")

  const deleteRecord = (id)=>{
    setRecords(records.filter(records=> records.id !== id));
  }
  return (
    <div >
<h1>Hybrowlabs</h1>

    <buton onClick={()=>{
      {addRecord()}
    }} style = {{ 
      padding:'8px 15px',
      background:'#4CAF50',
      color: '#fff',
      cursor:'pointer'
    }}>Add Record</buton>

<table style={{ width:'100%' , borderCollapse:'collapse', marginTop:'20px' }}>
  <thead>
    <tr>
      <th >Name</th>

      <th >Acion</th>


    </tr>
  </thead>
  <tbody>
    {records.map((data, index)=>{

     
      <tr key={index}>
      <td >{data?.name}</td>
      

      <td >

        <button onClick={()=>{
          deleteRecord(data.id)
        }} >Delete</button>
      </td>


      </tr>
      
    })}
  </tbody>
</table> 

{/* records.map((record)=>{}) */}

{/* <div>
  {records.map((record)=>{
    <div key={record.id}>
      <h1>name</h1>
      <span>{record.name}</span>

      <button onClick={deleteRecord}>delete</button>

    </div>
  })}
</div> */}



    </div>
  );
}


export default App;
